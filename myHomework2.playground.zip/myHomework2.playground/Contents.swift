import UIKit

/*
 Exercise 1
 The user opens a deposit in the bank for 5 years in the amount of 500_000 Eur. The interest rate per annum \(rate). Calculate the amount of income \(profit) at the end of the \(period).
 for _ in 1...period{
 }
 print("Amount of income after \(period) years will be \(profit) Eur. My total deposit will be \(deposit) Eur !")
 */
let deposit: Double = 500000 // original amount
let rate: Double = 0.05 // interest rate
let years: Int = 5 // years
var amount = deposit // amount value to original amount
for _ in 1...years {
    amount += amount * rate
}
print("The amount after \(years) years is \(String(format: "%.2f", amount)) EUR")
print("My total profit will be \(String(format: "%.2f", (amount - deposit))) EUR") // foramt to string and round 2 places afteer decimal


/*
 Exercise 2
 Create an integer array with any set of numbers and  print("My even numbers are: \(evenNumber)")
 Use a % inside the for loop.
 */
let arrayOne = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
for evenNumber in arrayOne {
    if evenNumber % 2 == 0 { // using modulo operator to to check if number is divided by 2 and reminder is 0
        print("My even numbers are: \(evenNumber)")
    }
}
/*
 Exercise 3
 Inside the for loop create randomNumber for the random Int calculation. Calculate and print("Number 5 will be after \(counter) shuffles"). Don't forget to make a break inside the if statement.
 */
let target = 5 // target numbeer
var cycles = 0 // define cycle starts from 0
for _ in 1...10 { // try 10 times
    let randomNumber = Int.random(in: 1...10) //random number from 1  - 10
    cycles += 1 // increment of cycles after each count
    if randomNumber == target {
        print("Number \(target) will be after \(cycles) shuffles")
        break //stops when target is found
    }
}

/*
 Exercise 4
 A bug is climbing to a 10-meter electric post. During the day, bug can climb two meters, during the night she slides down to 1 meter. Determine with the help of the cycle how many days bug will climb on the top of the post. Think about which loop to use in which situation. print("bug will spend \(numberOfDays)) to reach top of the post")
 */
var meters = 0
var days = 0
while meters <= 10 {
    meters += 2
    days += 1 //meters per day while meters are equal or less than 10
    if meters >= 10{ // if meters are less than then remove  1 meter
        break
    }
    meters -= 1
    
    }
print("bug will spend \(days) to reach top of the post")
